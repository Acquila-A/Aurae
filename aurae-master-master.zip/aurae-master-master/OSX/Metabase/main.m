//
//  main.m
//  Metabase
//
//  Created by Cam Saul on 9/21/15.
//  Copyright (c) 2015 Metabase. All rights reserved.
//

@import Cocoa;

int main(int argc, const char * argv[])
{
	return NSApplicationMain(argc, argv);
}
