# Aura Whitepaper
revision 1.8
updated by Anthony Lau & Francis Aw
