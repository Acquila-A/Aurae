A Pen created at CodePen.io. You can find this one at http://codepen.io/Arjun0728/pen/woqRVe.

 github repo for this pen: https://github.com/legomushroom/velocity