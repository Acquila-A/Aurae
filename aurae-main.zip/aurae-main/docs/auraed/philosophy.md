# Aurae Daemon Philosophy 
