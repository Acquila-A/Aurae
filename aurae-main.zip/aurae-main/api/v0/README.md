# V0 Aurae Standard Library 

The `V0` release is an experimental and risky API. This API should never be ran in production as it is subject to change at any time.

