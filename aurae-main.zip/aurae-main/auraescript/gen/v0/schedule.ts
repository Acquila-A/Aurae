/* eslint-disable */

export const protobufPackage = "schedule";
