# token
Attached are the token generation solidity scripts
