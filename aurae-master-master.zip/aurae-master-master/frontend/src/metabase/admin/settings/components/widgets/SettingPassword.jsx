import React from "react";

import SettingInput from "./SettingInput.jsx";

const SettingPassword = (props) =>
    <SettingInput {...props} type="password" />;

export default SettingPassword;
