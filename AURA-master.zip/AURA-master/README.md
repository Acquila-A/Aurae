# AURA-E
Adaptive Unified Reputation Algorithm (Economy)

<font size=+3><u><b>Current state of project</b></u></font><br/>
<ul>
<li><b>30th July 2018</b><br/>
We've finished our initial test on mDHT using entangled.<br/>
Mobile handsets can now connect to the mDHT network to form the SWARM</br><br/>
</li>

<li><b>July 2018</b><br/>
We are currently actively signing up ICO projects to be on the AURAE Ecosystem.<br/>
5 DAPPs have been release for their ICO Roadshows both on Google PlayStore and Apple AppStore.<br/>
The DAPP Wallet for the ICOs runs on Reactive Core 4 Nodes that simulates the AURAE Ecosystems.<br/><br/>
</li>

<li><b>June 2018</b><br/>
We have signed 5 new ICOS to be on the AURAE Ecosystem, which 5 of these ICOS<br/>
have bought AURAE Tokens which they will require for the X.509 certificates that<br/>
each DAPP user will require.<br/><br/></li>

<li><b>May 2018</b><br/>
making DHT/openDHT/mDHT work on the AURAE library for IOS/Android.<br/>
implementing the uTP Protocol for uPNP hole punching and for low latency networks.<br/><br/></li>

<li><b>Nov 2017 - April 2018</b></br>
Designs, Architecture drawing, planning the whole works.....<br/><br/></li>
</ul>
<br/>
for more information on implementation<br/>
please contact support@aurae.io<br/>
