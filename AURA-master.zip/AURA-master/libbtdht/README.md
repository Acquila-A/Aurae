btdht
======

The DHT implementation used by BitTorrent projects
