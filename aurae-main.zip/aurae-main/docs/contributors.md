# How to Contribute

The following sections cover some ways to contribute to the project. 

### How can I contribute support?

### How can I contribute code?
 - Read the [Code of Conduct](https://github.com/aurae-runtime/community/blob/main/CODE_OF_CONDUCT.md).
 - Read the [Contribution Guidelines](https://github.com/aurae-runtime/community/blob/main/CONTRIBUTING.md).
 - Sign the [CLA](https://cla.aurae.io/) to begin contributing as an individual contributor.

You're also encouraged to join the [Aurae Runtime Discord](https://discord.gg/aTe2Rjg5rq).